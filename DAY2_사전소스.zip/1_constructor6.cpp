#include <iostream>

// C50_ Use a factory function if you need ��virtual behavior��
// during initialization

struct Base
{
	Base() { }

	void foo() { init(); };

	void init() { std::cout << "Base::init" << std::endl; }     // 1
};

struct Derived : public Base
{
	int x;

	Derived() : x(10) {}

	void init() { std::cout << "Derived::init : " << x << std::endl; } // 2
};

int main()
{
	Derived d;
	d.foo();   // ��� ������ ������
}

