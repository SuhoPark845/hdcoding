#include <iostream>
#include <string>

class Object
{
public:
	std::string name;
	Object(const std::string& n) : name(n) {}
	Object(std::string&& n)      : name(std::move(n)) {}

};
int main()
{
	Object obj1("obj1");
	Object obj2("obj2");
	Object obj3 = obj1;
	Object obj4 = std::move(obj2);
	
	std::cout << obj1.name << std::endl;
	std::cout << obj2.name << std::endl;
}