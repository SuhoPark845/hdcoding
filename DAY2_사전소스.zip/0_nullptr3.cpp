// nullptr �� ����
void f1(int*  p) {}
void f2(char* p) {}

struct nullptr_t
{
};

nullptr_t mynullptr;

int main()
{
	f1(mynullptr);
	f2(mynullptr);
}