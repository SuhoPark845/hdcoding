template<typename F, typename ARG>
void caller(F f, ARG arg)
{
	f(arg);
}

void foo(int* p)
{
}

int main()
{
	int n = 0;
	foo(0);
	foo(n);
	
}