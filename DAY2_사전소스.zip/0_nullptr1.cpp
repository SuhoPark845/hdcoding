// 

int main()
{
	int* p1 = 0;
	int* p2 = nullptr;
}
